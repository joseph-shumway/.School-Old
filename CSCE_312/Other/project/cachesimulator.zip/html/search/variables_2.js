var searchData=
[
  ['cache_0',['cache',['../classcachesimulator.html#acc74e0dc17f59cbbdf3179bc8c43a235',1,'cachesimulator']]],
  ['cachesize_1',['cacheSize',['../classcachesimulator.html#afd0c292fd77455c0729c4b12d8d632b4',1,'cachesimulator']]]
];
