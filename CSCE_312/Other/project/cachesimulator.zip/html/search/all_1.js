var searchData=
[
  ['blocksize_0',['blockSize',['../classcachesimulator.html#a9c96e5074bfcd0cd42676f47319fdb39',1,'cachesimulator']]]
];
