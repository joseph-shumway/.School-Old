var searchData=
[
  ['ram_0',['ram',['../classcachesimulator.html#a8e12efcf905ea4255ca3249f4db098b1',1,'cachesimulator']]],
  ['replacementpolicy_1',['replacementPolicy',['../classcachesimulator.html#adbfce066db3ed261ec7d4d92309703bb',1,'cachesimulator']]]
];
