var searchData=
[
  ['hitpolicy_0',['hitPolicy',['../classcachesimulator.html#afdb27478f14ea6a7decda208b71c26ae',1,'cachesimulator']]]
];
