var searchData=
[
  ['physicaladdressbits_0',['physicalAddressBits',['../classcachesimulator.html#a1291982ced74a94b284bc70c0f234249',1,'cachesimulator']]]
];
