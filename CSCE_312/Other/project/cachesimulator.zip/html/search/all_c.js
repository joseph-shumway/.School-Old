var searchData=
[
  ['viewmenu_0',['viewMenu',['../classcachesimulator.html#ab721d314bc5fb0e787ccc33b2ffc614e',1,'cachesimulator']]]
];
