var searchData=
[
  ['numcachehits_0',['numCacheHits',['../classcachesimulator.html#a2b3f4108c66c89b8cbfeceb3b634a224',1,'cachesimulator']]],
  ['numcachemisses_1',['numCacheMisses',['../classcachesimulator.html#a26c78de76ca3140be34bc88d641c304f',1,'cachesimulator']]],
  ['numlinereplacements_2',['numLineReplacements',['../classcachesimulator.html#a25680d8a33919a730f8d5a8608628328',1,'cachesimulator']]],
  ['numoffsetbits_3',['numOffsetBits',['../classcachesimulator.html#af383e8fd2864c39f2097d6f07e9380e9',1,'cachesimulator']]],
  ['numsetbits_4',['numSetBits',['../classcachesimulator.html#a56814eb32c806e3f331dc32a75a64846',1,'cachesimulator']]],
  ['numsets_5',['numSets',['../classcachesimulator.html#abb2b16dd0632a595ebb25028cd734948',1,'cachesimulator']]],
  ['numtagbits_6',['numTagBits',['../classcachesimulator.html#aed92a4362a610e523065d12e115cb439',1,'cachesimulator']]],
  ['numtagdigits_7',['numTagDigits',['../classcachesimulator.html#a672bac6136998985ccd24afa42dc7f30',1,'cachesimulator']]]
];
