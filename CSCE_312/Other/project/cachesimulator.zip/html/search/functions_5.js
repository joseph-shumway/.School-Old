var searchData=
[
  ['print_0',['print',['../classcachesimulator.html#a3ee20486f2c6405d7d891c49811bd7cf',1,'cachesimulator.print(String input)'],['../classcachesimulator.html#a1b88752e8a8c98ac2004e51685cae1da',1,'cachesimulator.print(boolean input)']]],
  ['pront_1',['pront',['../classcachesimulator.html#a151c6edd190665429126aed0a0990284',1,'cachesimulator']]]
];
